featureBank = fieldnames(testsData{1}{1,1});

