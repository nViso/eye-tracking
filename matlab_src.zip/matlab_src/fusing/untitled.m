points = zeros(7,2,size(h,3));
for i = 1:size(h,3)
    hl = squeeze(h(:,:,i));
    mi = mdscale(hl,2);
    
    [d,z,t] = procrustes(xpoints,mi);
    mi = t.b*mi*t.T +t.c;
    points(:,:,i) = mi;
end
%%
figure;
hold on;
for i = 1:size(points,3)
    l = squeeze(points(:,:,i));
    scatter(l(:,1),l(:,2));
    plot(l([1 2],1),l([1 2],2));
    plot(l([1 3],1),l([1 3],2));
    plot(l([1 6],1),l([1 6],2));
    plot(l([2 4],1),l([2 4],2));
    plot(l([2 5],1),l([2 5],2));
    plot(l([5 6],1),l([5 6],2));
    plot(l([5 7],1),l([5 7],2));
    plot(l([6 7],1),l([6 7],2));
%     plot(l([2:4],1),l([2:4],2));
end
hold off;